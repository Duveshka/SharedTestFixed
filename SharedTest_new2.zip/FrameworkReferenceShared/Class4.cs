﻿#region test

using ReferencedMultipleShared;

#endregion

namespace FrameworkReferenceShared
{
    public class Class4
    {
        private void Test()
        {
            var reSharper1 = new ReferencedMultipleShared_ReSharper1_Renamed();
        }
    }
}