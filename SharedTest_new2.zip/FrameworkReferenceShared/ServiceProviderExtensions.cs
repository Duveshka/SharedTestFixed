﻿namespace FrameworkReferenceShared
{
    public static class ServiceProviderExtensions
    {
        public static void GetRequiredService<T>(this T serviceProvider)
        {
        }
    }
}