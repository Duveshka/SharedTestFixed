﻿namespace FrameworkReferenceShared
{
    public class Class1222
    {
        
    }
}