﻿namespace LinkedOriginCore
{
    internal class Linked5
    {
        public string Name { get; set; }

        public string Method1()
        {
            string s = "";
            return null;
        }
    }
}