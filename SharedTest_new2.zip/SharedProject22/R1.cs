﻿namespace SharedProject22
{
    public class R1
    {
    }
}