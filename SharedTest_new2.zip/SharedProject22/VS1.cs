﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedProject22
{
    class VS1
    {
    }
}
