﻿#region test

using LinkedOriginCore;
using LinkedOriginFramework;

#endregion

namespace LinkedDestinationFramework
{
    public class LinkedDestinationFramework1
    {
        private void LinkedDestinationFramework1_Method1()
        {
            new Linked8().Method5();
            var linked1 = new Linked1();
            // TODO: test
            linked1.Method1();
            linked1.Method41_11(2);

            linked1.Method12(1);

            var linked5 = new Linked5_Renamed();
            linked5.Name = "";

            var linked9 = new Linked9();
            linked9.Method2();

            var linked2 = new Linked2();
            linked2.Method1(null);
        }
    }
}