﻿#include "NewClass1.h"

void NewClass1::do_work()
{
	auto t = 1;
	auto t2 = 2;
}

void NewClass1::test2()
{
	do_work();
}
