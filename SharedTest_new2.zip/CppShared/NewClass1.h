﻿#pragma once

class NewClass1
{
public:

	static void do_work();
	static void test2();
	
};
