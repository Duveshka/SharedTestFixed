class vs_shared_1
{
public:
	static void Test1();
};

void vs_shared_1::Test1()
{
	auto t = 1;
	auto t2 = 2;
}
