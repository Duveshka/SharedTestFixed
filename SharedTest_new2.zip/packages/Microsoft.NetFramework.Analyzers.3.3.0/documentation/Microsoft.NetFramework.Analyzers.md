# Microsoft.NetFramework.Analyzers

## [CA1058](https://docs.microsoft.com/visualstudio/code-quality/ca1058): Types should not extend certain base types

|Item|Value|
|-|-|
|Category|Design|
|Enabled|True|
|Severity|Warning|
|CodeFix|False|

### Rule description

An externally visible type extends certain base types. Use one of the alternatives.

## [CA2153](https://docs.microsoft.com/visualstudio/code-quality/ca2153): Do Not Catch Corrupted State Exceptions

|Item|Value|
|-|-|
|Category|Security|
|Enabled|True|
|Severity|Warning|
|CodeFix|False|

### Rule description

Catching corrupted state exceptions could mask errors (such as access violations), resulting in inconsistent state of execution or making it easier for attackers to compromise system. Instead, catch and handle a more specific set of exception type(s) or re-throw the exception.

## [CA3075](https://docs.microsoft.com/visualstudio/code-quality/ca3075): Insecure DTD processing in XML

|Item|Value|
|-|-|
|Category|Security|
|Enabled|True|
|Severity|Warning|
|CodeFix|False|

### Rule description

Using XmlTextReader.Load(), creating an insecure XmlReaderSettings instance when invoking XmlReader.Create(), setting the InnerXml property of the XmlDocument and enabling DTD processing using XmlUrlResolver insecurely can lead to information disclosure. Replace it with a call to the Load() method overload that takes an XmlReader instance, use XmlReader.Create() to accept XmlReaderSettings arguments or consider explicitly setting secure values. The DataViewSettingCollectionString property of DataViewManager should always be assigned from a trusted source, the DtdProcessing property should be set to false, and the XmlResolver property should be changed to XmlSecureResolver or null. 

## [CA3076](https://docs.microsoft.com/visualstudio/code-quality/ca3076): Insecure XSLT script processing.

|Item|Value|
|-|-|
|Category|Security|
|Enabled|True|
|Severity|Warning|
|CodeFix|False|

### Rule description

Providing an insecure XsltSettings instance and an insecure XmlResolver instance to XslCompiledTransform.Load method is potentially unsafe as it allows processing script within XSL, which on an untrusted XSL input may lead to malicious code execution. Either replace the insecure XsltSettings argument with XsltSettings.Default or an instance that has disabled document function and script execution, or replace the XmlResolver argurment with null or an XmlSecureResolver instance. This message may be suppressed if the input is known to be from a trusted source and external resource resolution from locations that are not known in advance must be supported.

## [CA3077](https://docs.microsoft.com/visualstudio/code-quality/ca3077): Insecure Processing in API Design, XmlDocument and XmlTextReader

|Item|Value|
|-|-|
|Category|Security|
|Enabled|True|
|Severity|Warning|
|CodeFix|False|

### Rule description

Enabling DTD processing on all instances derived from XmlTextReader or  XmlDocument and using XmlUrlResolver for resolving external XML entities may lead to information disclosure. Ensure to set the XmlResolver property to null, create an instance of XmlSecureResolver when processing untrusted input, or use XmlReader.Create method with a secure XmlReaderSettings argument. Unless you need to enable it, ensure the DtdProcessing property is set to false. 

## [CA3147](https://docs.microsoft.com/visualstudio/code-quality/ca3147): Mark Verb Handlers With Validate Antiforgery Token

|Item|Value|
|-|-|
|Category|Security|
|Enabled|True|
|Severity|Warning|
|CodeFix|False|

### Rule description

Missing ValidateAntiForgeryTokenAttribute on controller action {0}

