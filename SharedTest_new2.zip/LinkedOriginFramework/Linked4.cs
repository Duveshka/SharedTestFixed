﻿// lilia.shamsutdinova

namespace LinkedOriginFramework
{
    public class Linked4
    {
        
    }
}