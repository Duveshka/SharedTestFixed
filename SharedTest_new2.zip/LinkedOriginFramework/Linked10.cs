﻿namespace LinkedOriginFramework
{
    public class Linked10
    {
        public void Method1()
        {
            throw new System.NotImplementedException();
        }
    }
}