﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedProjectRef1
{
    class VS1
    {
    }
}
