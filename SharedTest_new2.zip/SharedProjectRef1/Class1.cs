﻿namespace SharedProjectRef1
{
    public class Class1
    {
        
    }
}