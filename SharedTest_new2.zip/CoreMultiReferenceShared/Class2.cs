﻿#region test

using ReferencedMultipleShared;

#endregion

namespace CoreMultiReferenceShared
{
    public class Class2
    {
        private void Test()
        {
            var reSharper1 = new ReferencedMultipleShared_ReSharper1_Renamed();
        }
    }
}