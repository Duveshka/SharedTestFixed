﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NotReferencedShared.NewFolder
{
    class NotReferenced1
    {
        private void Test()
        {
            // no ReSharper
        }
    }
}
