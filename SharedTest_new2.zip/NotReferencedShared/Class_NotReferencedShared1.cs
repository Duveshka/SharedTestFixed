﻿class Class_NotReferencedShared
{
    public string Class_NotReferencedShared_Name { get; set; }
    public int Class_NotReferencedShared_Age { get; set; }


    class Class_NotReferencedShared_Inner
    {

        private static void Test(int number)
        {

            static void Test2()
            {




            }
                
            //comment
            // test comment
        }
    }
}