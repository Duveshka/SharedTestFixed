﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace LinkedOriginCore
{
    class Linked9
    {
        public void Method1()
        {
        }

        public string Method2()
        {
            throw new NotImplementedException();
        }
    }
}
