﻿// lilia.shamsutdinova

using System;

namespace LinkedOriginCore
{
    public class Linked8
    {
        public string S { get; set; }

        public void Method1()
        {
            int t = 1234;
            Console.WriteLine(t);
            throw new System.NotImplementedException();
        }

        public void Method2()
        {
            throw new System.NotImplementedException();
        }

        public void Method3()
        {
            throw new System.NotImplementedException();
        }

        public string Method4(int i)
        {
            string s = "new string";
            return s;
        }

        public void Method5()
        {
            throw new System.NotImplementedException();
        }
    }
}