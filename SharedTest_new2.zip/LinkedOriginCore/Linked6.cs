﻿// lilia.shamsutdinova

namespace LinkedOriginCore
{
    public class Linked6
    {
        
    }
}