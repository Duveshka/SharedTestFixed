﻿namespace LinkedOriginCore
{
    public class TestClass
    {
        public class MyClass1
        {
            public int I1 { get; private set; }

            private void Test()
            {
                new Linked5_Renamed();
                I1 = 1;
            }
        }
    }
}