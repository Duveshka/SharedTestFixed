﻿using SharedProject22;

namespace LinkedOriginCore
{
    public class Class1
    {
        private void TEst(string s)
        {
            new ReSharper1().Method1();
            new ReSharper1().Method3(s, s);
        }
    }
}