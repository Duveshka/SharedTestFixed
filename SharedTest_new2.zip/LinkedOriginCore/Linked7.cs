﻿namespace LinkedOriginCore
{
    public class Linked7
    {
    }
}