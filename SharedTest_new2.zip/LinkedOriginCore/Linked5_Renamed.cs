﻿namespace LinkedOriginCore
{
    internal class Linked5_Renamed
    {
        public string Name { get; set; }

        public string Method1()
        {
            var s = "";
            return null;
        }
    }
}