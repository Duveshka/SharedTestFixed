﻿namespace CoreMultiReferencedSharedOne.NewFolder
{
    public class TC
    {
        private void Test()
        {
            string s = "";

            var s2 = "";
        }
    }
}