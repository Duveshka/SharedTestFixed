﻿#region test

using System;

#endregion

namespace CoreMultiReferencedSharedOne.NewFolder
{
    public class Class1
    {
        private void Test()
        {
            string s1 = "";

            var format1 = "1";
            var format11 = "1";
            Console.WriteLine(format1);
        }
    }
}