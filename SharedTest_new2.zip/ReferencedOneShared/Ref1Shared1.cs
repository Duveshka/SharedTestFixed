﻿#region test

using System;

#endregion

namespace CoreMultiReferencedSharedOne
{
    public class Ref1Shared1
    {
        private void Test()
        {
            var s = "";


            var format = "";
            Console.WriteLine(format);
        }
    }
}