﻿



namespace CoreMultiReferencedSharedOne.ReferencedOneShared
{
    public class OneShared1
    {
        
    }
}