﻿namespace CoreMultiReferencedSharedOne
{
    public class Class1
    {
        private void Test()
        {
            string s = "";
        }
    }
}