﻿// lilia.shamsutdinova

namespace ReferencedOneShared
{
    // ReferencedOneShared_VSCreatedBeforeReference1
    public class ReferencedOneShared_VSCreatedBeforeReference1
    {
        public string ReferencedOneSharer_VSCreatedBeforeReference_Name2;


        // some comment


        public ReferencedOneShared_VSCreatedBeforeReference1(string referencedOneSharerVsCreatedBeforeReferenceName2)
        {
            ReferencedOneSharer_VSCreatedBeforeReference_Name2 = referencedOneSharerVsCreatedBeforeReferenceName2;
        }

        public ReferencedOneShared_VSCreatedBeforeReference1()
        {
            // test s
            throw new System.NotImplementedException();
        }

        public void Method2()
        {
            throw new System.NotImplementedException();
        }

        public void Method1()
        {
            throw new System.NotImplementedException();
        }


        public void Method3()
        {
            throw new System.NotImplementedException();
        }
    }
}