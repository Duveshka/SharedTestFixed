﻿// lilia.shamsutdinova

namespace ReferencedOneShared
{
    public class ReferencedOneShared_ReSharper2
    {
        
    }
}