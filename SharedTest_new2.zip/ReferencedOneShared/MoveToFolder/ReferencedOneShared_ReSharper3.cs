﻿#region test

using System;

#endregion

namespace ReferencedOneShared
{
    public class ReferencedOneShared_ReSharper3
    {
        public string Method4()
        {
            var referencedOneSharedVs1 = new ReferencedOneShared_VS1(false);

            // some comment


            throw new NotImplementedException();
        }
    }
}