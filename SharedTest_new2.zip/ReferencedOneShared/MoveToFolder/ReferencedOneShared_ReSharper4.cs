﻿namespace ReferencedOneShared.NewFolder
{
    public class ReferencedOneShared_ReSharper4
    {
        public string Name { get; set; }

        public void Method1()
        {
            Name = "";
        }
    }
}