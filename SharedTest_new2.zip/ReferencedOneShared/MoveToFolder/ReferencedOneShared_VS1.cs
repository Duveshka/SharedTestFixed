﻿namespace ReferencedOneShared
{
    internal class ReferencedOneShared_VS1
    {
        public bool Field1 = true;

        public ReferencedOneShared_VS1()
        {
            // Test
        }

        public ReferencedOneShared_VS1(bool field1)
        {
            Field1 = field1;
        }
    }
}