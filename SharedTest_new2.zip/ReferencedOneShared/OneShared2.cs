﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReferencedOneShared
{
    class OneShared2
    {
    }
}
