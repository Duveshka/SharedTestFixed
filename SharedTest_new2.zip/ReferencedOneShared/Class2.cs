﻿namespace CoreMultiReferencedSharedOne
{
    public class Class2
    {
    }
}