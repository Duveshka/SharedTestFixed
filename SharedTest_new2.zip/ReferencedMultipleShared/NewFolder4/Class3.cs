﻿namespace NewFolder4
{
    public class Class3
    {
    }
}