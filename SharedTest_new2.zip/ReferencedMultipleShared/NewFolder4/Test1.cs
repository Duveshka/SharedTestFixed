﻿namespace NewFolder4
{
    public class Test1
    {
    }
}