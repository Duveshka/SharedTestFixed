﻿namespace NewFolder4
{
    public class Class8
    {
    }
}