﻿namespace NewFolder4
{
    public class Class15
    {
        private void Test()
        {
            var s1 = "";
        }
    }
}