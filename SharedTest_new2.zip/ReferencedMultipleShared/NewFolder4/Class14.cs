﻿namespace NewFolder4
{
    public class Class14
    {
        private void Test()
        {
            var t1 = 1;
            var s = "";
            var s2 = "";
        }
    }
}