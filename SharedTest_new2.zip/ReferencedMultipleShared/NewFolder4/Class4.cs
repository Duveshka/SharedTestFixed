﻿namespace NewFolder4
{
    public class Class4
    {
        private void rearrangeCode_moveRight(bool b)
        {
            {
                if (b) // Comment 1: offset for readability
                {
                    // Comment 2: the empty lines below are for future code

                    var ss = ""; // worse     fromatting ever
                    var ss1 = "";
                }
            } // Comment 3: offset for readability


            {
                int t; // Move right
                // Test
            }
        }
    }
}