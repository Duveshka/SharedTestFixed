﻿namespace NewFolder4
{
    public class B
    {
    }
}