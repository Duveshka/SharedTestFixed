﻿namespace NewFolder4
{
    public class Class7
    {
    }
}