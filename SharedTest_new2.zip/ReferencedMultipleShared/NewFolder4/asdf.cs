﻿#region test

using System;

#endregion

     namespace NewFolder4   
{
    internal class A5 : IInterface
    {
        public void Test()
        {
            int t = 1; 
            throw new NotImplementedException();
        }
    }

    internal interface IInterface
    {
    }
}