﻿namespace NewFolder4
{
    public class Class5
    {
    }
}