﻿namespace ReferencedMultipleShared
{
    internal interface IReferencedMultipleShared_VS1
    {
        string Name1 { get; set; }
        string Name2_Renamed { get; set; }
        void Method1();
        void Method2(int parameter212);
        void Method3();
        void Method4();
        void Method5();
        void Method6();
    }
}