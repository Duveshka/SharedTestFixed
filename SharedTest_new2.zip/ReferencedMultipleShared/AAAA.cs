﻿namespace CoreMultiReferenceShared
{
    public class AAAA
    {
    }
}