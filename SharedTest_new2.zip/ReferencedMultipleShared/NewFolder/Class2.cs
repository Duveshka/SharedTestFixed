﻿namespace CoreMultiReferenceShared.NewFolder
{
    public class Class2
    {
    }
}