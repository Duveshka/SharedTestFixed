﻿namespace CoreMultiReferenceShared.NewFolder
{
    public class Class1
    {
    }
}