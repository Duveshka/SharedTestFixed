﻿namespace CoreMultiReferenceShared.NewFolder
{
    public class Class4
    {
    }
}