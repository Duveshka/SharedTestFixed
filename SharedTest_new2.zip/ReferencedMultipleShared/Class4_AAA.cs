﻿namespace CoreMultiReferenceShared
{
    public class Class4_AAA
    {
    }
}