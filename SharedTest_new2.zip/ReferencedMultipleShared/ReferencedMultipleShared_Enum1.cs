﻿namespace ReferencedMultipleShared
{
    public enum ReferencedMultipleShared_Enum1
    {
        A,
        B
    }
}