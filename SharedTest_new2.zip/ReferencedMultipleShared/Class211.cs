﻿namespace CoreMultiReferenceShared
{
    public class Class211
    {
    }
}