﻿namespace ReferencedMultipleShared
{
    internal class Class1
    {
    }
}