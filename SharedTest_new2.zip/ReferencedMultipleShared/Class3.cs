﻿namespace CoreMultiReferenceShared
{
    public class Class344
    {
    }
}