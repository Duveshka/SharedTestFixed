namespace ReferencedMultipleShared_1
{
    internal static class Shape_Copy
    {
        private class InnerShapeClass
        {
            private void Test()
            {
            }
        }
    }
}