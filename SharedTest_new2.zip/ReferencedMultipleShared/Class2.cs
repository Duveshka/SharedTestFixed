﻿namespace CoreMultiReferenceShared
{
    public class Class2_1111


    {
    }
}