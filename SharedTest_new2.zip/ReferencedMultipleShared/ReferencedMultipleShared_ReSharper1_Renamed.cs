﻿#region test

using System;

#endregion

namespace ReferencedMultipleShared
{
    public class ReferencedMultipleShared_ReSharper1_Renamed
    {
        public void Method1()
        {
            var reSharper = new ReferencedMultipleShared_ReSharper1_Renamed();
            var mehtodToMove = ReferencedMultipleShared_ReSharper2.MehtodToMove();
            var mehtodToMove1 = "null";
            Console.WriteLine(reSharper);
        }
    }
}