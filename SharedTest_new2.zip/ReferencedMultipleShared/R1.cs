﻿namespace CoreMultiReferenceShared
{
    public class R1
    {
    }
}